"""Bitmap definition of the '42' glyph used inside generated mazes.

The pattern is expressed as a list of strings. Each character represents
one maze cell: ``"1"`` means the cell must be forced fully closed (part of
the visible digit), ``"0"`` means the cell is left untouched and behaves as
a normal maze cell.
"""

from __future__ import annotations

# 5 columns wide, 7 rows tall, classic dot-matrix digit shapes.
_DIGIT_4 = (
    "10010",
    "10010",
    "10010",
    "11111",
    "00010",
    "00010",
    "00010",
)

_DIGIT_2 = (
    "11110",
    "00001",
    "00001",
    "01110",
    "10000",
    "10000",
    "11111",
)


def build_pattern(gap: int = 1) -> list[str]:
    """Combine the '4' and '2' digit bitmaps side by side.

    Args:
        gap: Number of empty columns separating the two digits.

    Returns:
        A list of equal-length strings (rows) made of '0'/'1' characters.
    """
    rows: list[str] = []
    spacer = "0" * gap
    for row4, row2 in zip(_DIGIT_4, _DIGIT_2):
        rows.append(row4 + spacer + row2)
    return rows


PATTERN_42: list[str] = build_pattern()
PATTERN_HEIGHT: int = len(PATTERN_42)
PATTERN_WIDTH: int = len(PATTERN_42[0])
